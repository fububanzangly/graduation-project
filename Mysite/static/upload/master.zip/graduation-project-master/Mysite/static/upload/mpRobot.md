## 微信公众平台机器人

公众平台聊天机器人，可以自定义聊天命令，适用于未认证公众号。

## 配置

- 注册微信公众平台账号
- 填写公众号平台开发中基本配置的服务器回调地址
- 拷贝 mp 下的 config-dist.py 为 config.py
- 填写你的 appid，secret，token，AESKEY
- 申请图灵机器人 key，secret
- python run.py
