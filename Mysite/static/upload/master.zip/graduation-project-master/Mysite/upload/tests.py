from django.test import TestCase
import pygit2
#pygit2.clone_repository('https://github.com/fububanzangly/mpRobot.git',path="/Users/liyang/Documents/Python/graduation-project/Mysite/upload/upload/master",checkout_branch="master",callbacks=None)
# Create your tests here.
