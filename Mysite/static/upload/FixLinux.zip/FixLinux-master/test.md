# test
```c
int main (){
  int a=0;
}
```
